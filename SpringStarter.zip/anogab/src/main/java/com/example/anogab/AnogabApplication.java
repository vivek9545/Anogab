package com.example.anogab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnogabApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnogabApplication.class, args);
	}

}
