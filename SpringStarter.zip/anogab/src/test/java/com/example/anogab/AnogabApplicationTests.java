package com.example.anogab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnogabApplicationTests {

	@Test
	void contextLoads() {
	}

}
